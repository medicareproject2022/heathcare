package com.medicare.healthcare.orderdetail.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

 
import com.medicare.healthcare.orderdetail.model.Order;
 
import com.medicare.healthcare.orderdetail.repository.OrderRepository;

@Service
public class OrderService {

	@Autowired

	public OrderRepository orderRepository;

	public Order save(Order order) {
		return orderRepository.save(order);

	}

	public List<Order> listAll() {
		return orderRepository.findAll();
	}
	
	public Order get(Integer id) {
	    return orderRepository.findById(id).get();
	}
	 
	public void delete(Integer id) {
		orderRepository.deleteById(id);
	}

}
