package com.medicare.healthcare.orderdetail.service;

public class OrderItemService {

}
