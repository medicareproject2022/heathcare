package com.medicare.healthcare.orderdetail.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "order")
public class Order {

	@Id
   @GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;

	@Column(name = "usr_id")
	private Integer usrId;

	@Column(name = "order_date")
	private Date orderdate;
	
	@Column(name="medicine_name")
	private String medicinename;

	@Column(name = "order_price")
	private long orderprice;

	@Column(name = "order_quantity")
	private long orderquantity;

	@Column(name = "total_price")
	private Double totalPrice;
	
	
	
	
	public Order() {
		super();
		// TODO Auto-generated constructor stub
	}



	public Order(Integer id, Integer usrId, Date orderdate, String medicinename, long orderprice, long orderquantity,
			Double totalPrice) {
		super();
		this.id = id;
		this.usrId = usrId;
		this.orderdate = orderdate;
		this.medicinename = medicinename;
		this.orderprice = orderprice;
		this.orderquantity = orderquantity;
		this.totalPrice = totalPrice;
	}
	
	

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getUsrId() {
		return usrId;
	}

	public void setUsrId(Integer usrId) {
		this.usrId = usrId;
	}

	public Date getOrderdate() {
		return orderdate;
	}

	public void setOrderdate(Date orderdate) {
		this.orderdate = orderdate;
	}

	public String getMedicinename() {
		return medicinename;
	}

	public void setMedicinename(String medicinename) {
		this.medicinename = medicinename;
	}

	public long getOrderprice() {
		return orderprice;
	}

	public void setOrderprice(long orderprice) {
		this.orderprice = orderprice;
	}

	public long getOrderquantity() {
		return orderquantity;
	}

	public void setOrderquantity(long orderquantity) {
		this.orderquantity = orderquantity;
	}

	public Double getTotalPrice() {
		return totalPrice;
	}

	public void setTotalPrice(Double totalPrice) {
		this.totalPrice = totalPrice;
	}

	

	 
	
}
