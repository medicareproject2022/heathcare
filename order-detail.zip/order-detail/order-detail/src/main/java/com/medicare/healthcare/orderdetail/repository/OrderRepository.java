package com.medicare.healthcare.orderdetail.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.medicare.healthcare.orderdetail.model.Order;

public interface OrderRepository extends JpaRepository<Order, Integer> {
	
	/* List<Order> findAllByUserIdOrderByCreatedDateDesc(Integer userId); */

}
