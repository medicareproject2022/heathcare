package com.healthcare.medicare.paymentService.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;

import com.healthcare.medicare.paymentService.model.Payment;

public interface PaymentServiceRepository extends JpaRepository <Payment, Integer> {
	
	

}
