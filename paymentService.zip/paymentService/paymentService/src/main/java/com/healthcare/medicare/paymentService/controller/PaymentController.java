package com.healthcare.medicare.paymentService.controller;

import java.util.List;
import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
 

import com.healthcare.medicare.paymentService.model.Payment;
import com.healthcare.medicare.paymentService.repository.PaymentServiceRepository;
import com.healthcare.medicare.paymentService.service.PaymentService;

@RestController
@RequestMapping("/payment")
public class PaymentController {
	
	@Autowired
	PaymentService paymentService;
	
	@GetMapping("/payment")
	public List<Payment> list() {
	    return paymentService.listAll();
	}

	@GetMapping("/payment/{id}")
	public ResponseEntity<Payment> getPaymentById(@PathVariable Integer id) {
	    try {
	    	Payment payment = paymentService.getPaymentById(id);
	        return new ResponseEntity<Payment>(payment, HttpStatus.OK);
	    } catch (NoSuchElementException e) {
	        return new ResponseEntity<Payment>(HttpStatus.NOT_FOUND);
	    }      
	}
	
	@PostMapping("/addPaymentDetail")
	public void add(@RequestBody Payment payment) {
		paymentService.save(payment);
	}
	
	@PutMapping("/payment/{id}")
	public ResponseEntity<?> update(@RequestBody Payment payment, @PathVariable Integer id) {
	    try {
	    	Payment existPayment= paymentService.getPaymentById(id);
	    	existPayment.setCard_ExpiryDate(payment.getCard_ExpiryDate());
	    	existPayment.setCard_Holder_Name(payment.getCard_Holder_Name());
	    	existPayment.setCard_Number(payment.getCard_Number());
	    	existPayment.setCvv(payment.getCvv());
	    	existPayment.setUserId(payment.getUserId());
	    	paymentService.save(existPayment);
	        return new ResponseEntity<>(HttpStatus.OK);
	    } catch (NoSuchElementException e) {
	        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	    }      
	}

	
	@DeleteMapping("/payment/{id}")
	public void delete(@PathVariable Integer id) {
		paymentService.delete(id);
	}
}
