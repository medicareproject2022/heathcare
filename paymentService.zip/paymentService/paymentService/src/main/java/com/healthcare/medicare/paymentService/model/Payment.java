package com.healthcare.medicare.paymentService.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

 


@Entity
public class Payment {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	
	 
	private String card_Type;
	
	 
	private String card_ExpiryDate;
	
	 
	private String card_Number;
	
	 
	private String card_Holder_Name;
	
	 
	private Integer cvv;
	
	@Column(name="userId")
	private Integer userId;
	

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getCard_Type() {
		return card_Type;
	}

	public void setCard_Type(String card_Type) {
		this.card_Type = card_Type;
	}

	public String getCard_ExpiryDate() {
		return card_ExpiryDate;
	}

	public void setCard_ExpiryDate(String card_ExpiryDate) {
		this.card_ExpiryDate = card_ExpiryDate;
	}

	public String getCard_Number() {
		return card_Number;
	}

	public void setCard_Number(String card_Number) {
		this.card_Number = card_Number;
	}

	public String getCard_Holder_Name() {
		return card_Holder_Name;
	}

	public void setCard_Holder_Name(String card_Holder_Name) {
		this.card_Holder_Name = card_Holder_Name;
	}

	public Integer getCvv() {
		return cvv;
	}

	public void setCvv(Integer cvv) {
		this.cvv = cvv;
	}

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}
	
	

}
