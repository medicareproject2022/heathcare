package com.healthcare.medicare.paymentService.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.healthcare.medicare.paymentService.model.Payment;
import com.healthcare.medicare.paymentService.repository.PaymentServiceRepository;
import com.healthcare.medicare.paymentService.service.PaymentService;

@Service
public class PaymentServiceImpl {
	
	@Autowired
	PaymentServiceRepository paymentServiceRepository;

	 

}
