package com.healthcare.medicare.paymentService.dto;

public class OrderDetailsDTO {
	
	private Integer id;
	
	private String address;
	
	private String orderDate;
	
	private String  orderQuatity;
	
	private double  orderPrice;
	
	private double totalPrice;
	
	private Integer userId;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(String orderDate) {
		this.orderDate = orderDate;
	}

	public String getOrderQuatity() {
		return orderQuatity;
	}

	public void setOrderQuatity(String orderQuatity) {
		this.orderQuatity = orderQuatity;
	}

	public double getOrderPrice() {
		return orderPrice;
	}

	public void setOrderPrice(double orderPrice) {
		this.orderPrice = orderPrice;
	}

	public double getTotalPrice() {
		return totalPrice;
	}

	public void setTotalPrice(double totalPrice) {
		this.totalPrice = totalPrice;
	}
	
	
	
	
	

}
