package com.healthcare.medicare.paymentService.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.healthcare.medicare.paymentService.model.Payment;
import com.healthcare.medicare.paymentService.repository.PaymentServiceRepository;

@Service
@Transactional
public class PaymentService {
	
	
	@Autowired
	private PaymentServiceRepository paymentServiceRepository;
	 
	public List<Payment> listAll() {
	    return paymentServiceRepository.findAll();
	}
	 
	public void save(Payment payment) {
	 paymentServiceRepository.save(payment);
		//System.out.println("payment"+payment.getCard_Holder_Name());
	}
	 
	public Payment getPaymentById(Integer id) {
	    return paymentServiceRepository.findById(id).get();
	}
	 
	public void delete(Integer id) {
		paymentServiceRepository.deleteById(id);
	}

}
